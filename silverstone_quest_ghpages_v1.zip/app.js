
(function(){
  const $ = (sel, el=document) => el.querySelector(sel);
  const $$ = (sel, el=document) => Array.from(el.querySelectorAll(sel));

  const state = {
    user: JSON.parse(localStorage.getItem('ssc_user') || 'null'),
    progress: JSON.parse(localStorage.getItem('ssc_progress') || '{"currentLevel":0,"found":{}}'),
  };

  const cfg = window.QUEST_CONFIG;
  const codesByLevel = cfg.codes.reduce((acc, row) => {
    if(!acc[row.level]) acc[row.level] = [];
    acc[row.level].push(row.code);
    return acc;
  }, {});

  function save(){
    localStorage.setItem('ssc_user', JSON.stringify(state.user));
    localStorage.setItem('ssc_progress', JSON.stringify(state.progress));
  }

  function resetAll(){
    localStorage.removeItem('ssc_user');
    localStorage.removeItem('ssc_progress');
    state.user = null;
    state.progress = { currentLevel: 0, found: {} };
    route();
  }

  // Screens
  function screenWelcome(){
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <h2>Welcome, Adventurer</h2>
      <p>Begin your quest to find hidden castles across Silver Stone Castle. You'll need a blacklight object to participate.</p>
      <div class="space"></div>
      <button class="primary" id="start">Get Started</button>
    `;
    el.querySelector('#start').onclick = () => route('purchase');
    return el;
  }

  function screenPurchase(){
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <h2>Purchase Blacklight</h2>
      <p class="badge">Required to begin Level 1</p>
      <div class="space"></div>
      <div class="field">
        <label>Your full name</label>
        <input id="name" type="text" placeholder="Jane Doe" />
      </div>
      <div class="field">
        <label>Email</label>
        <input id="email" type="email" placeholder="you@example.com" />
      </div>
      <div class="field">
        <label>Phone (optional)</label>
        <input id="phone" type="text" placeholder="(555) 555-5555" />
      </div>
      <div class="space"></div>
      <div class="row">
        <button class="primary" id="activate">Activate & Begin</button>
        <button class="secondary" id="back">Back</button>
      </div>
    `;
    el.querySelector('#back').onclick = () => route();
    el.querySelector('#activate').onclick = () => {
      const name = $('#name', el).value.trim();
      const email = $('#email', el).value.trim();
      const phone = $('#phone', el).value.trim();
      if(!name || !email){
        alert('Please enter your name and email to activate.');
        return;
      }
      state.user = { name, email, phone, blacklightPurchased: true, registeredAt: new Date().toISOString() };
      state.progress.currentLevel = 1;
      state.progress.found['1'] = [];
      save();
      route('level');
    };
    return el;
  }

  function screenLevel(){
    const level = state.progress.currentLevel || 1;
    const total = (codesByLevel[level] || []).length;
    const found = state.progress.found[level] || [];
    const complete = found.length >= total;

    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <h2>Level ${level} <small>${found.length}/${total} castles found</small></h2>
      <div class="progress"><div style="width:${Math.min(100, (found.length/total)*100)}%"></div></div>
      <div class="space"></div>
      ${ complete ? `
        <p>🎉 Level ${level} completed!</p>
        <p class="badge">Proceed to the kiosk to unlock the next level.</p>
        <div class="space"></div>
        <button class="primary" id="kiosk">Go to Kiosk</button>
      ` : `
        <div class="field">
          <label>Enter castle code for Level ${level}</label>
          <input id="code" type="text" placeholder="Enter 5-character code" maxlength="5" />
        </div>
        <div class="row">
          <button class="primary" id="submit">Submit Code</button>
          <button class="secondary" id="showFound">Show Found</button>
        </div>
        <div class="space"></div>
        <div class="list" id="foundList" style="display:none"></div>
      `}
    `;

    if(complete){
      el.querySelector('#kiosk').onclick = () => route('kiosk');
    } else {
      el.querySelector('#showFound').onclick = () => {
        const list = $('#foundList', el);
        list.style.display = list.style.display === 'none' ? 'grid' : 'none';
        renderFound(list, found);
      };
      el.querySelector('#submit').onclick = () => {
        const input = $('#code', el);
        const code = input.value.trim().toUpperCase();
        if(!code){ alert('Enter a code.'); return; }
        // Validate: code must belong to current level and not already found
        if(!codesByLevel[level].includes(code)){
          alert('Invalid code for this level.');
          return;
        }
        if(found.includes(code)){
          alert('You already entered this code.');
          return;
        }
        found.push(code);
        state.progress.found[level] = found;
        save();
        route('level');
      };
    }

    return el;
  }

  function renderFound(container, found){
    container.innerHTML = '';
    found.forEach((code, idx) => {
      const row = document.createElement('div');
      row.className = 'item';
      row.innerHTML = `<strong>${code}</strong><small>#${idx+1}</small>`;
      container.appendChild(row);
    });
  }

  function screenKiosk(){
    const level = state.progress.currentLevel;
    const maxLevel = Math.max(...Object.keys(codesByLevel).map(Number));
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <h2>Kiosk — Unlock Next Level</h2>
      <p>Show this screen to staff to unlock the next level after payment.</p>
      <p class="badge">Current level: ${level} / Max: ${maxLevel}</p>
      <div class="space"></div>
      <div class="field">
        <label>Staff Passcode</label>
        <input id="pass" type="password" placeholder="Enter staff passcode" />
      </div>
      <div class="row">
        <button class="primary" id="unlock">Unlock Next Level</button>
        <button class="secondary" id="back">Back</button>
      </div>
    `;
    el.querySelector('#back').onclick = () => route('level');
    el.querySelector('#unlock').onclick = () => {
      const val = $('#pass', el).value;
      if(val !== cfg.staffPasscode){
        alert('Incorrect passcode.');
        return;
      }
      const next = level + 1;
      if(!codesByLevel[next]){
        alert('You have completed all levels. Congratulations!');
        return;
      }
      // Unlock next level
      state.progress.currentLevel = next;
      if(!state.progress.found[next]) state.progress.found[next] = [];
      save();
      alert(`Level ${next} unlocked!`);
      route('level');
    };
    return el;
  }

  function screenStaffLogin(){
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <h2>Staff Tools</h2>
      <p class="badge">Admin / Kiosk utilities</p>
      <div class="field">
        <label>Passcode</label>
        <input id="pass" type="password" placeholder="Enter staff passcode" />
      </div>
      <div class="row">
        <button class="primary" id="enter">Enter</button>
        <button class="secondary" id="back">Back</button>
      </div>
    `;
    el.querySelector('#back').onclick = () => route('level');
    el.querySelector('#enter').onclick = () => {
      const val = $('#pass', el).value;
      if(val !== cfg.staffPasscode){
        alert('Incorrect passcode.');
        return;
      }
      route('staff');
    };
    return el;
  }

  function screenStaff(){
    const el = document.createElement('div');
    el.className = 'card';
    const u = state.user;
    const lvl = state.progress.currentLevel || 0;
    el.innerHTML = `
      <h2>Staff Dashboard</h2>
      <div class="list">
        <div class="item"><span>User</span><strong>${u ? (u.name + " (" + u.email + ")") : "No user"}</strong></div>
        <div class="item"><span>Current Level</span><strong>${lvl}</strong></div>
      </div>
      <div class="space"></div>
      <div class="row">
        <button class="primary" id="unlock">Unlock Next Level</button>
        <button class="secondary" id="codes">View Codes</button>
      </div>
      <div class="space"></div>
      <div id="codesBox" class="list" style="display:none"></div>
    `;
    el.querySelector('#unlock').onclick = () => {
      const next = lvl + 1;
      if(!cfg.codes.some(r => r.level === next)){
        alert('All levels complete.');
        return;
      }
      state.progress.currentLevel = next;
      if(!state.progress.found[next]) state.progress.found[next] = [];
      save();
      alert(`Level ${next} unlocked.`);
      route('level');
    };
    el.querySelector('#codes').onclick = () => {
      const box = $('#codesBox', el);
      box.style.display = box.style.display === 'none' ? 'grid' : 'none';
      if(box.innerHTML.trim() === ''){
        // show current level codes for verification
        const lvl = state.progress.currentLevel || 1;
        const codes = (cfg.codes.filter(r => r.level === lvl)).map(r => r.code);
        codes.forEach((c, i) => {
          const row = document.createElement('div');
          row.className = 'item';
          row.innerHTML = `<strong>${c}</strong><small>Level ${lvl} #${i+1}</small>`;
          box.appendChild(row);
        });
      }
    };
    return el;
  }

  function route(view){
    const app = document.getElementById('app');
    app.innerHTML = '';
    if(!state.user){
      app.appendChild(screenWelcome());
      return;
    }
    if(state.progress.currentLevel === 0){
      app.appendChild(screenWelcome());
      return;
    }
    switch(view){
      case 'purchase': app.appendChild(screenPurchase()); break;
      case 'kiosk': app.appendChild(screenKiosk()); break;
      case 'staff-login': app.appendChild(screenStaffLogin()); break;
      case 'staff': app.appendChild(screenStaff()); break;
      case 'level':
      default: app.appendChild(screenLevel()); break;
    }
  }

  // footer buttons
  document.getElementById('resetBtn').onclick = resetAll;
  document.getElementById('staffBtn').onclick = () => route('staff-login');

  // Initial route
  route();
})();
